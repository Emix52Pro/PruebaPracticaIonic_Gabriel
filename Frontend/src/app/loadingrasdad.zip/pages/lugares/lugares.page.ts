import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonButtons, IonButton, IonIcon, IonFabButton, IonGrid, IonRow, IonCol, IonCardHeader, IonCard, IonCardTitle, IonFab, IonItem, IonList, IonAvatar, IonImg, IonLabel } from '@ionic/angular/standalone';
import { Lugar } from 'src/app/models/Lugar';
import { Subscription } from 'rxjs';
import { Router, RouterLink } from '@angular/router';
import { LugaresService } from 'src/app/service/lugares.service';
import { addIcons } from 'ionicons';
import { ModalController } from '@ionic/angular/standalone';
import { addOutline, airplane, globe } from 'ionicons/icons';
import { AgregarlugarPage } from '../agregarlugar/agregarlugar.page';
import { LoadingComponent } from 'src/app/Componentes/loading/loading.component';

@Component({
  selector: 'app-lugares',
  templateUrl: './lugares.page.html',
  styleUrls: ['./lugares.page.scss'],
  standalone: true,
  imports: [IonFab, IonFabButton, IonIcon, IonContent, IonHeader, IonTitle, IonGrid, IonCard, IonCardHeader, IonCardTitle, IonRow, IonCol, IonToolbar, IonButtons, IonButton, CommonModule, FormsModule, LoadingComponent]
})
export class LugaresPage implements OnInit {
  lugares: Lugar[] = [];
  isLoading = true;
  private lugarSubscription?: Subscription;

  constructor(
    private router: Router, 
    private lugaresService: LugaresService,
    private modalCtrl: ModalController
  ) {
    addIcons({airplane, globe, addOutline});
  }

  ngOnInit() {
    this.loadData();
  }

  private loadData() {
    this.isLoading = true;
    setTimeout(() => {
      this.lugares = this.lugaresService.getLugares();
      this.isLoading = false;
    }, 1500);

    this.lugarSubscription = this.lugaresService.lugarActualizado$.subscribe((lugar: Lugar | null) => {
      if (lugar === null) {
        this.lugares = this.lugaresService.getLugares();
      } else {
        const index = this.lugares.findIndex(l => l.id === lugar.id);
        if (index !== -1) {
          this.lugares[index] = lugar;
        }
      }
    });
  }

  async abrirModal() {
    const modal = await this.modalCtrl.create({
      component: AgregarlugarPage
    });

    modal.onDidDismiss().then((data) => {
      if (data.data) {
        this.lugaresService.addLugar(data.data);
        this.lugares = this.lugaresService.getLugares();
      }
    });

    return await modal.present();
  }

  verDetalle(id: number) {
    this.router.navigate(['/detallelugar', id]);
  }

  ngOnDestroy() {
    this.lugarSubscription?.unsubscribe();
  }
}
